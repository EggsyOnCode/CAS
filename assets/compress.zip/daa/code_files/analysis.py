import time
import random
from insertionSort import insertion_sort
from selectionSort import selection_sort
from bubbleSort import bubble_sort
from heapSort import heap_sort
from mergeSort import merge_sort
from counting import counting_sort
from radixSort import radix_sort
from bucketSort import bucket_sort
from quickSort import quick_sort
import matplotlib.pyplot as plt

algos = [insertion_sort, selection_sort, bubble_sort, heap_sort, merge_sort, radix_sort, bucket_sort, counting_sort, quick_sort]
algo_names = ["insertion sort", "selection sort", "bubble sort", "Heap sort", "Merge sort","Radix Sort","Bucket Sort", "Counting Sort", "Quick Sort"]

def measure_execution_time(sort_func):
    execution_times = []
    for size in range(500,10001,500):
        arr = [random.randint(0, 1000) for _ in range(size)]
        start_time = time.time()
        sort_func(arr)
        end_time = time.time()
        execution_times.append((end_time - start_time)*1000)
    return execution_times


for x in range(len(algos)):
    algo_sort_times = measure_execution_time(algos[x])

    sizes = list(range(500,10001,500))
    times = []
    for _, time_taken in enumerate(algo_sort_times):
        # print(f"Size: {size}, {algo_names[x]} Sort Time taken: {time_taken:.6f} milliseconds")
        # sizes.append(size)
        times.append(time_taken)
    
    plt.plot(sizes, times) 
    plt.xlabel('array size')
    plt.ylabel("time in millisec")
    plt.ylim(0,50)
    plt.grid(True)
    
plt.legend(algo_names)
plt.show()