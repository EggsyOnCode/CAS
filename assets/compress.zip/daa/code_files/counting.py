def counting_sort(arr):
    if not arr:  # Check if the array is empty
        return arr
    max_val = max(arr) + 1
    count = [0] * max_val  # Create a count array to store count of individual elements
    for num in arr:
        count[num] += 1
    result = []
    # Append the elements in sorted order based on their counts
    for i in range(max_val):
        result.extend([i] * count[i])
    return result

# Example usage:
arr = [64, 25, 12, 22, 11]
counting_sort(arr)
print("Sorted array:", arr)
