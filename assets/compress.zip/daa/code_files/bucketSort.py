def bucket_sort(arr):
    if not arr:  # Check if the array is empty
        return arr

    max_val = max(arr)
    bucket_size = 10
    num_buckets = (int(max_val) // bucket_size) + 1  # Convert max_val to integer
    buckets = [[] for _ in range(num_buckets)]

    for num in arr:
        bucket_index = num // bucket_size
        buckets[bucket_index].append(num)

    for bucket in buckets:
        bucket.sort()

    sorted_arr = []
    for bucket in buckets:
        sorted_arr.extend(bucket)

    return sorted_arr

# Example usage:
arr = [64, 25, 12, 22, 11]
bucket_sort(arr)
print("Sorted array:", arr)